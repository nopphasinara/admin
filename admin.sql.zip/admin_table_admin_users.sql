
CREATE TABLE `admin_users` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_users` VALUES(1, 'admin', '$2y$10$rh9ucJVaMWOxhSzgketax.d8YscbOsBCkB2gp3tNINtRBkhfpkjQC', 'Administrator', 'images/Untitled-3.jpg', NULL, '2017-07-19 06:23:47', '2018-04-12 10:59:04');
INSERT INTO `admin_users` VALUES(2, 'test', '$2y$10$LdKig3pCzJc2qS2fPH/ixeunTBnRQJo.sJKDga.eVhbLmayKjesfe', 'test', NULL, NULL, '2017-09-02 20:23:06', '2017-09-02 20:23:06');
