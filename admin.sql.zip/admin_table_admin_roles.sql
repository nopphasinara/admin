
CREATE TABLE `admin_roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_roles` VALUES(1, 'Administrator', 'administrator', '2017-07-19 06:23:47', '2017-07-19 06:23:47');
INSERT INTO `admin_roles` VALUES(2, 'test', 'test', '2017-09-02 20:23:33', '2017-09-02 20:23:33');
INSERT INTO `admin_roles` VALUES(3, 'Developer', 'developer', '2017-09-07 00:43:21', '2017-09-07 00:43:21');
