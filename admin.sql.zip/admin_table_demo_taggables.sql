
CREATE TABLE `demo_taggables` (
  `tag_id` int(10) UNSIGNED NOT NULL,
  `taggable_id` int(10) UNSIGNED NOT NULL,
  `taggable_type` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_taggables` VALUES(4, 2, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(5, 2, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(3, 2, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(4, 13, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(1, 14, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(2, 14, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(3, 14, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(4, 14, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(19, 9, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(22, 15, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 17, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 17, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(19, 17, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 17, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(27, 17, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 8, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 8, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 12, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 12, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(19, 12, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 12, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 18, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 1, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(19, 1, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 1, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(21, 1, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(22, 1, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(21, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(22, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(27, 19, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 20, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(21, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(22, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(27, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(19, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(23, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(31, 21, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(1, 2, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(2, 2, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(3, 2, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(4, 2, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(16, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(3, 3, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(5, 3, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(12, 5, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 3, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(21, 3, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 7, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(16, 7, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 7, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 9, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 4, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 4, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(21, 5, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 6, 'App\\Models\\Video', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 10, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(16, 10, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 10, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 10, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 11, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(16, 1, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 1, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(22, 1, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(23, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 16, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(21, 16, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(17, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 4, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(16, 6, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(20, 6, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(22, 6, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(23, 6, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
INSERT INTO `demo_taggables` VALUES(18, 20, 'App\\Models\\Post', '0000-00-00 00:00:00', '0000-00-00 00:00:00');
