
CREATE TABLE `demo_categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `logo` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_categories` VALUES(1, 0, 1, 'PHP', 'Best language', '2017-01-03 07:03:35', '2017-01-04 08:06:53', '');
INSERT INTO `demo_categories` VALUES(3, 1, 3, 'Laravel', '', '2017-01-03 07:08:14', '2017-01-03 07:11:26', '');
INSERT INTO `demo_categories` VALUES(4, 1, 8, 'Lumen', '', '2017-01-03 07:08:30', '2017-01-04 08:16:34', '');
INSERT INTO `demo_categories` VALUES(5, 1, 9, 'Yii', '', '2017-01-03 07:08:59', '2017-01-04 08:16:34', '');
INSERT INTO `demo_categories` VALUES(6, 1, 2, 'Symfony', '', '2017-01-03 07:10:14', '2017-01-03 07:11:26', '');
INSERT INTO `demo_categories` VALUES(7, 1, 10, 'Slim', '', '2017-01-03 07:10:41', '2017-01-04 08:16:34', '');
INSERT INTO `demo_categories` VALUES(8, 1, 11, 'Slix', '', '2017-01-03 07:10:56', '2017-01-04 08:16:34', '');
INSERT INTO `demo_categories` VALUES(9, 0, 1, 'Python', 'hahahahah', '2017-01-03 07:11:41', '2017-01-14 18:43:45', '');
INSERT INTO `demo_categories` VALUES(10, 9, 4, 'Django', '', '2017-01-03 07:12:37', '2017-01-14 18:43:48', '');
INSERT INTO `demo_categories` VALUES(11, 9, 3, 'Flask', '', '2017-01-03 07:12:52', '2017-01-14 18:43:48', '');
INSERT INTO `demo_categories` VALUES(12, 9, 2, 'Tornado', '', '2017-01-03 07:13:30', '2017-01-14 18:43:45', '');
INSERT INTO `demo_categories` VALUES(13, 9, 5, 'Webpy', '', '2017-01-03 07:13:49', '2017-01-14 18:43:48', '');
INSERT INTO `demo_categories` VALUES(14, 0, 6, 'Ruby', '', '2017-01-03 18:25:48', '2017-01-14 18:43:45', '');
INSERT INTO `demo_categories` VALUES(15, 14, 7, 'Rails', '', '2017-01-03 18:25:59', '2017-01-14 18:43:45', '');
INSERT INTO `demo_categories` VALUES(16, 3, 4, '5.1', '', '2017-01-03 18:39:32', '2017-01-04 08:22:18', '');
INSERT INTO `demo_categories` VALUES(17, 3, 5, '5.2', '', '2017-01-03 18:39:42', '2017-01-04 08:22:18', '');
INSERT INTO `demo_categories` VALUES(18, 3, 6, '5.3', '', '2017-01-03 18:39:51', '2017-01-04 08:22:18', '');
INSERT INTO `demo_categories` VALUES(19, 3, 7, '5.4', '', '2017-01-03 18:40:02', '2017-01-04 08:16:34', '');
