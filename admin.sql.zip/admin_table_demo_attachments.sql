
CREATE TABLE `demo_attachments` (
  `id` int(11) NOT NULL,
  `article_id` int(11) NOT NULL,
  `slug` varchar(255) DEFAULT NULL,
  `files` text,
  `pictures` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `demo_attachments` VALUES(1, 1, 'asdasdasdasd...', '[]', '[\"images\\/6c093171e83629c7379606123c5af4e0.jpeg\",\"images\\/0e3c7754b1dacad73dfba899b7e8886d.jpeg\"]', '2017-10-11 15:48:17', '2017-09-12 22:01:37');
