
CREATE TABLE `demo_paintings` (
  `id` int(10) UNSIGNED NOT NULL,
  `painter_id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `completed_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_paintings` VALUES(26, 7, '1111', 'asdasdad', '2017-01-23 16:00:00', '2017-01-23 08:20:14', '2017-01-23 08:20:14');
INSERT INTO `demo_paintings` VALUES(28, 7, '222222', 'asdasasd', '2017-01-23 16:00:00', '2017-01-23 08:56:34', '2017-01-23 08:56:34');
INSERT INTO `demo_paintings` VALUES(29, 7, '3333333', 'asdasdasdas', '2017-01-23 16:00:00', '2017-01-23 08:56:34', '2017-01-23 08:56:34');
INSERT INTO `demo_paintings` VALUES(30, 10, '123', '123123123', '2017-02-05 16:00:00', '2017-02-05 08:03:24', '2017-02-05 08:03:24');
INSERT INTO `demo_paintings` VALUES(31, 11, '1111111', 'asdasdasd', '2017-02-12 16:00:00', '2017-02-13 05:44:23', '2017-02-13 05:44:23');
INSERT INTO `demo_paintings` VALUES(32, 11, '2222222222', 'asdasdasdasdadadad', '2017-02-23 16:00:00', '2017-02-13 05:44:23', '2017-02-13 05:44:23');
INSERT INTO `demo_paintings` VALUES(33, 12, '阿三打算的', 'image/962bd40735fae6cd848b7afb0fb30f2442a70f69.jpg', '2017-04-13 16:00:00', '2017-04-19 01:44:40', '2017-04-19 22:55:36');
INSERT INTO `demo_paintings` VALUES(34, 12, '2222222222', 'image/5630259_145141531001_2.jpg', '2017-04-20 16:00:00', '2017-04-19 01:44:40', '2017-04-20 00:10:29');
INSERT INTO `demo_paintings` VALUES(35, 13, '111111', '111111', '2017-09-10 16:00:00', '2017-09-10 20:02:45', '2017-09-10 20:03:22');
INSERT INTO `demo_paintings` VALUES(36, 13, '2221', '222', '2017-09-10 16:00:00', '2017-09-10 20:02:55', '2017-09-10 20:03:22');
INSERT INTO `demo_paintings` VALUES(37, 13, '3333331', '33333', '2017-09-10 16:00:00', '2017-09-10 20:02:55', '2017-09-10 20:03:22');
INSERT INTO `demo_paintings` VALUES(38, 14, 'hello', '敖德萨所多阿萨德啊', '2017-09-23 16:00:00', '2017-09-24 04:21:01', '2017-09-24 04:21:01');
INSERT INTO `demo_paintings` VALUES(39, 14, '啊实打实大撒阿三', '阿三大声道阿萨德阿三', '2017-09-23 16:00:00', '2017-09-24 04:21:01', '2017-09-24 04:21:01');
