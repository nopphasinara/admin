
CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` VALUES(1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES(2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES(3, '2016_01_04_173148_create_admin_tables', 1);
INSERT INTO `migrations` VALUES(4, '2017_07_17_040159_create_settings_table', 2);
INSERT INTO `migrations` VALUES(5, '2017_07_17_040159_create_messages_table', 3);
INSERT INTO `migrations` VALUES(6, '2017_07_17_040159_create_exceptions_table', 4);
