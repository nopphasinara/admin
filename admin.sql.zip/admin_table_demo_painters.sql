
CREATE TABLE `demo_painters` (
  `id` int(10) UNSIGNED NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `bio` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_painters` VALUES(13, 'admin123123', '啊啊啊啊啊啊啊', '2017-09-10 19:44:56', '2017-09-10 20:03:14');
INSERT INTO `demo_painters` VALUES(14, '梵高', '啊哈哈哈哈哈', '2017-09-24 04:21:01', '2017-09-24 04:21:01');
