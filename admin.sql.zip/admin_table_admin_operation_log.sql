
CREATE TABLE `admin_operation_log` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_operation_log` VALUES(1, 1, 'demo/widgets/editors', 'GET', '127.0.0.1', '[]', '2017-10-11 15:49:40', '2017-10-11 15:49:40');
INSERT INTO `admin_operation_log` VALUES(2, 1, 'admin/auth/menu', 'GET', '::1', '[]', '2018-04-12 10:51:48', '2018-04-12 10:51:48');
INSERT INTO `admin_operation_log` VALUES(3, 1, 'admin/exceptions', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:01', '2018-04-12 10:52:01');
INSERT INTO `admin_operation_log` VALUES(4, 1, 'admin/backup', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:03', '2018-04-12 10:52:03');
INSERT INTO `admin_operation_log` VALUES(5, 1, 'admin/media', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:05', '2018-04-12 10:52:05');
INSERT INTO `admin_operation_log` VALUES(6, 1, 'admin/api-tester', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:07', '2018-04-12 10:52:07');
INSERT INTO `admin_operation_log` VALUES(7, 1, 'admin/logs', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:08', '2018-04-12 10:52:08');
INSERT INTO `admin_operation_log` VALUES(8, 1, 'admin/scheduling', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:10', '2018-04-12 10:52:10');
INSERT INTO `admin_operation_log` VALUES(9, 1, 'admin/config', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:13', '2018-04-12 10:52:13');
INSERT INTO `admin_operation_log` VALUES(10, 1, 'admin/helpers/scaffold', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:20', '2018-04-12 10:52:20');
INSERT INTO `admin_operation_log` VALUES(11, 1, 'admin/helpers/terminal/database', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:21', '2018-04-12 10:52:21');
INSERT INTO `admin_operation_log` VALUES(12, 1, 'admin/helpers/terminal/artisan', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:23', '2018-04-12 10:52:23');
INSERT INTO `admin_operation_log` VALUES(13, 1, 'admin/helpers/routes', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:26', '2018-04-12 10:52:26');
INSERT INTO `admin_operation_log` VALUES(14, 1, 'admin/widgets/form-1', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:32', '2018-04-12 10:52:32');
INSERT INTO `admin_operation_log` VALUES(15, 1, 'admin/widgets/form-2', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:34', '2018-04-12 10:52:34');
INSERT INTO `admin_operation_log` VALUES(16, 1, 'admin/widgets/form-3', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:39', '2018-04-12 10:52:39');
INSERT INTO `admin_operation_log` VALUES(17, 1, 'admin/movies/in-theaters', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:44', '2018-04-12 10:52:44');
INSERT INTO `admin_operation_log` VALUES(18, 1, 'admin/china/province', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:52:51', '2018-04-12 10:52:51');
INSERT INTO `admin_operation_log` VALUES(19, 1, 'admin/china/province', 'GET', '::1', '[]', '2018-04-12 10:52:53', '2018-04-12 10:52:53');
INSERT INTO `admin_operation_log` VALUES(20, 1, 'admin/world/country', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:07', '2018-04-12 10:53:07');
INSERT INTO `admin_operation_log` VALUES(21, 1, 'admin/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:13', '2018-04-12 10:53:13');
INSERT INTO `admin_operation_log` VALUES(22, 1, 'admin/posts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:17', '2018-04-12 10:53:17');
INSERT INTO `admin_operation_log` VALUES(23, 1, 'admin/images', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:27', '2018-04-12 10:53:27');
INSERT INTO `admin_operation_log` VALUES(24, 1, 'admin/videos', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:32', '2018-04-12 10:53:32');
INSERT INTO `admin_operation_log` VALUES(25, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:34', '2018-04-12 10:53:34');
INSERT INTO `admin_operation_log` VALUES(26, 1, 'admin/videos', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:35', '2018-04-12 10:53:35');
INSERT INTO `admin_operation_log` VALUES(27, 1, 'admin/images', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:43', '2018-04-12 10:53:43');
INSERT INTO `admin_operation_log` VALUES(28, 1, 'admin/posts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:44', '2018-04-12 10:53:44');
INSERT INTO `admin_operation_log` VALUES(29, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:45', '2018-04-12 10:53:45');
INSERT INTO `admin_operation_log` VALUES(30, 1, 'admin/categories', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:47', '2018-04-12 10:53:47');
INSERT INTO `admin_operation_log` VALUES(31, 1, 'admin/multiple-images', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:48', '2018-04-12 10:53:48');
INSERT INTO `admin_operation_log` VALUES(32, 1, 'admin/categories', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:50', '2018-04-12 10:53:50');
INSERT INTO `admin_operation_log` VALUES(33, 1, 'admin/tags', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:54', '2018-04-12 10:53:54');
INSERT INTO `admin_operation_log` VALUES(34, 1, 'admin/painters', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:55', '2018-04-12 10:53:55');
INSERT INTO `admin_operation_log` VALUES(35, 1, 'admin/tags', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:53:58', '2018-04-12 10:53:58');
INSERT INTO `admin_operation_log` VALUES(36, 1, 'admin/auth/users', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:54:06', '2018-04-12 10:54:06');
INSERT INTO `admin_operation_log` VALUES(37, 1, 'admin/auth/roles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:54:08', '2018-04-12 10:54:08');
INSERT INTO `admin_operation_log` VALUES(38, 1, 'admin/auth/permissions', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:54:12', '2018-04-12 10:54:12');
INSERT INTO `admin_operation_log` VALUES(39, 1, 'admin/auth/menu', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:54:14', '2018-04-12 10:54:14');
INSERT INTO `admin_operation_log` VALUES(40, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"%23pjax-container\"}', '2018-04-12 10:54:21', '2018-04-12 10:54:21');
INSERT INTO `admin_operation_log` VALUES(41, 1, 'admin/helpers/routes', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:56:22', '2018-04-12 10:56:22');
INSERT INTO `admin_operation_log` VALUES(42, 1, 'admin/helpers/routes', 'GET', '::1', '{\"_pjax\":\"#pjax-container\",\"action\":\"movie\",\"uri\":null}', '2018-04-12 10:56:30', '2018-04-12 10:56:30');
INSERT INTO `admin_operation_log` VALUES(43, 1, 'admin/helpers/routes', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:56:32', '2018-04-12 10:56:32');
INSERT INTO `admin_operation_log` VALUES(44, 1, 'admin/movies/top250', 'GET', '::1', '[]', '2018-04-12 10:57:33', '2018-04-12 10:57:33');
INSERT INTO `admin_operation_log` VALUES(45, 1, 'admin/world/language', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:57:50', '2018-04-12 10:57:50');
INSERT INTO `admin_operation_log` VALUES(46, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"%23pjax-container\"}', '2018-04-12 10:57:56', '2018-04-12 10:57:56');
INSERT INTO `admin_operation_log` VALUES(47, 1, 'admin/auth/setting', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:57:59', '2018-04-12 10:57:59');
INSERT INTO `admin_operation_log` VALUES(48, 1, 'admin/auth/setting', 'PUT', '::1', '{\"name\":\"Administrator\",\"password\":\"$2y$10$rh9ucJVaMWOxhSzgketax.d8YscbOsBCkB2gp3tNINtRBkhfpkjQC\",\"password_confirmation\":\"$2y$10$rh9ucJVaMWOxhSzgketax.d8YscbOsBCkB2gp3tNINtRBkhfpkjQC\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/admin.goldfishcreativethailand.local\\/admin\"}', '2018-04-12 10:59:04', '2018-04-12 10:59:04');
INSERT INTO `admin_operation_log` VALUES(49, 1, 'admin/auth/setting', 'GET', '::1', '[]', '2018-04-12 10:59:05', '2018-04-12 10:59:05');
INSERT INTO `admin_operation_log` VALUES(50, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"%23pjax-container\"}', '2018-04-12 10:59:08', '2018-04-12 10:59:08');
INSERT INTO `admin_operation_log` VALUES(51, 1, 'admin', 'GET', '::1', '[]', '2018-04-12 10:59:10', '2018-04-12 10:59:10');
INSERT INTO `admin_operation_log` VALUES(52, 1, 'admin/multiple-images', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:59:28', '2018-04-12 10:59:28');
INSERT INTO `admin_operation_log` VALUES(53, 1, 'admin/tags', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 10:59:32', '2018-04-12 10:59:32');
INSERT INTO `admin_operation_log` VALUES(54, 1, 'admin/tags', 'GET', '::1', '[]', '2018-04-12 11:02:49', '2018-04-12 11:02:49');
INSERT INTO `admin_operation_log` VALUES(55, 1, 'admin/tags/16', 'PUT', '::1', '{\"hot\":\"off\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_method\":\"PUT\"}', '2018-04-12 11:03:07', '2018-04-12 11:03:07');
INSERT INTO `admin_operation_log` VALUES(56, 1, 'admin/tags/16', 'PUT', '::1', '{\"hot\":\"on\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_method\":\"PUT\"}', '2018-04-12 11:03:54', '2018-04-12 11:03:54');
INSERT INTO `admin_operation_log` VALUES(57, 1, 'admin/tags/16', 'PUT', '::1', '{\"hot\":\"off\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_method\":\"PUT\"}', '2018-04-12 11:03:56', '2018-04-12 11:03:56');
INSERT INTO `admin_operation_log` VALUES(58, 1, 'admin/tags', 'GET', '::1', '[]', '2018-04-12 11:03:57', '2018-04-12 11:03:57');
INSERT INTO `admin_operation_log` VALUES(59, 1, 'admin/tags/16', 'PUT', '::1', '{\"new\":\"on\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_method\":\"PUT\"}', '2018-04-12 11:04:00', '2018-04-12 11:04:00');
INSERT INTO `admin_operation_log` VALUES(60, 1, 'admin/tags', 'GET', '::1', '[]', '2018-04-12 11:04:01', '2018-04-12 11:04:01');
INSERT INTO `admin_operation_log` VALUES(61, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"%23pjax-container\"}', '2018-04-12 11:04:11', '2018-04-12 11:04:11');
INSERT INTO `admin_operation_log` VALUES(62, 1, 'admin/painters', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:04:30', '2018-04-12 11:04:30');
INSERT INTO `admin_operation_log` VALUES(63, 1, 'admin/painters/13/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:04:33', '2018-04-12 11:04:33');
INSERT INTO `admin_operation_log` VALUES(64, 1, 'admin/painters', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:04:45', '2018-04-12 11:04:45');
INSERT INTO `admin_operation_log` VALUES(65, 1, 'admin/painters/13/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:04:52', '2018-04-12 11:04:52');
INSERT INTO `admin_operation_log` VALUES(66, 1, 'admin/categories', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:05:04', '2018-04-12 11:05:04');
INSERT INTO `admin_operation_log` VALUES(67, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:05:09', '2018-04-12 11:05:09');
INSERT INTO `admin_operation_log` VALUES(68, 1, 'admin/articles/1', 'PUT', '::1', '{\"_method\":\"PUT\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_orderable\":\"0\"}', '2018-04-12 11:05:20', '2018-04-12 11:05:20');
INSERT INTO `admin_operation_log` VALUES(69, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:05:21', '2018-04-12 11:05:21');
INSERT INTO `admin_operation_log` VALUES(70, 1, 'admin/articles/4', 'PUT', '::1', '{\"_method\":\"PUT\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_orderable\":\"0\"}', '2018-04-12 11:05:23', '2018-04-12 11:05:23');
INSERT INTO `admin_operation_log` VALUES(71, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:05:23', '2018-04-12 11:05:23');
INSERT INTO `admin_operation_log` VALUES(72, 1, 'admin/articles/4', 'PUT', '::1', '{\"_method\":\"PUT\",\"_token\":\"jLF8rAJ8xuHSJCZTFnVCgIwqv5D43ZAaHdaWsagz\",\"_orderable\":\"1\"}', '2018-04-12 11:05:26', '2018-04-12 11:05:26');
INSERT INTO `admin_operation_log` VALUES(73, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:05:27', '2018-04-12 11:05:27');
INSERT INTO `admin_operation_log` VALUES(74, 1, 'admin/articles', 'GET', '::1', '[]', '2018-04-12 11:05:31', '2018-04-12 11:05:31');
INSERT INTO `admin_operation_log` VALUES(75, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"%23pjax-container\"}', '2018-04-12 11:07:29', '2018-04-12 11:07:29');
INSERT INTO `admin_operation_log` VALUES(76, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:07:50', '2018-04-12 11:07:50');
INSERT INTO `admin_operation_log` VALUES(77, 1, 'admin/articles/4/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:08:03', '2018-04-12 11:08:03');
INSERT INTO `admin_operation_log` VALUES(78, 1, 'admin/articles', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:08:10', '2018-04-12 11:08:10');
INSERT INTO `admin_operation_log` VALUES(79, 1, 'admin/posts', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:08:28', '2018-04-12 11:08:28');
INSERT INTO `admin_operation_log` VALUES(80, 1, 'admin/posts/6/edit', 'GET', '::1', '{\"_pjax\":\"#pjax-container\"}', '2018-04-12 11:08:58', '2018-04-12 11:08:58');
INSERT INTO `admin_operation_log` VALUES(81, 1, 'admin', 'GET', '::1', '{\"_pjax\":\"%23pjax-container\"}', '2018-04-12 11:09:10', '2018-04-12 11:09:10');
