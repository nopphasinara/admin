
CREATE TABLE `demo_user_sns` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `qq` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `wechat` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `weibo` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `github` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `google` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `facebook` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `twitter` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_user_sns` VALUES(1, 6, NULL, '21312312313', NULL, NULL, NULL, NULL, NULL, '2017-01-09 18:20:16', '2017-03-30 02:23:39');
INSERT INTO `demo_user_sns` VALUES(2, 12, '', '23123123', '', '', '', '', '', '2017-01-22 07:24:30', '2017-01-22 07:24:30');
INSERT INTO `demo_user_sns` VALUES(3, 18, '', '大声大声道', '', '', '', '', '', '2017-01-22 07:24:42', '2017-01-22 07:24:42');
INSERT INTO `demo_user_sns` VALUES(4, 24, '', '123123123', '', '', '', '', '', '2017-01-22 07:25:20', '2017-01-22 07:25:20');
INSERT INTO `demo_user_sns` VALUES(5, 3, '', '123123123', '', '', '', '', '', '2017-03-08 06:07:18', '2017-03-08 06:07:18');
INSERT INTO `demo_user_sns` VALUES(6, 15, '', 'asdasdasdasd', '', '', '', '', '', '2017-03-08 06:07:29', '2017-03-08 06:07:29');
INSERT INTO `demo_user_sns` VALUES(7, 9, '', 'asdasdasdad', '', '', '', '', '', '2017-03-08 06:07:45', '2017-03-08 06:07:45');
