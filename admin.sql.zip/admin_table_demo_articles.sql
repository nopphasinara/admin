
CREATE TABLE `demo_articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(190) COLLATE utf8_unicode_ci NOT NULL,
  `content` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `picture` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_articles` VALUES(1, 'Web fonts, boy, I don\'t know', 'I spent a week', 'images/20aedc7c13979878323a5681ecd52a39.png', 2, '2016-11-04 06:31:33', '2018-04-12 11:05:26');
INSERT INTO `demo_articles` VALUES(3, '111111111axsaxa', '1231231231231111asdasd', 'image/u=798459138,2950856503&fm=23&gp=0.jpg', 5, '2016-11-04 06:32:52', '2017-10-11 15:37:58');
INSERT INTO `demo_articles` VALUES(4, 'Admin', '按时打算打算打算打算 ', 'image/a62c54ee695ae8467d88dd2930a167b6.jpeg', 0, '2016-12-22 07:14:05', '2018-04-12 11:05:26');
