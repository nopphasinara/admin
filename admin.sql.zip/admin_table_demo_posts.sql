
CREATE TABLE `demo_posts` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `author_id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `content` text COLLATE utf8_unicode_ci NOT NULL,
  `rate` int(11) NOT NULL,
  `released` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '0',
  `keywords` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `foo_bar` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `release_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `extra` text COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_posts` VALUES(1, 'Et fuga sunt autem a ut dicta.', '35', 'Dicta repellendus provident omnis voluptates. Veritatis nobis amet voluptas aut et tempore hic. Cumque quae tempora vel quas corporis. Corrupti ullam eos molestiae non.', 4, '1', 'cum', NULL, '1975-03-29 12:54:05', '2014-02-15 14:21:10', '2017-09-04 19:27:59', '2017-09-04 19:27:59', NULL);
INSERT INTO `demo_posts` VALUES(2, 'Voluptatem voluptas officia commodi sed deleniti.', 'ut', 'Iusto sunt facere consequuntur laborum ut unde expedita. Corrupti inventore non suscipit rerum. Quisquam suscipit est quo accusantium cum minus soluta. Qui non id corporis veniam et consequuntur et.', 0, '0', 'voluptatibus', NULL, '1987-01-09 09:47:59', '2013-12-22 13:34:43', '2017-09-04 19:27:59', '2017-09-04 19:27:59', NULL);
INSERT INTO `demo_posts` VALUES(3, 'Illum autem in magni ab soluta ex consequatur.', 'velit', 'Minus explicabo qui autem incidunt vel dignissimos dolore. Libero enim a officiis repellat voluptas aliquam culpa. Eaque molestias minus ipsam eaque accusantium. Explicabo ut corrupti perspiciatis neque labore quae suscipit.', 6, '1', 'laudantium', NULL, '2006-06-12 04:50:27', '1979-06-14 01:34:13', '2017-09-04 19:27:59', '2017-09-04 19:27:59', NULL);
INSERT INTO `demo_posts` VALUES(4, NULL, '114', 'Minima quis ducimus natus sit delectus magni possimus. Corporis corporis modi amet non voluptatum eos. Aut eius iste facilis cumque ut.', 13, '0', 'dolorum', 'hello', '1979-01-10 14:10:09', '1970-01-26 07:56:32', '2017-10-11 15:31:29', NULL, '{\"title\":\"222222\",\"image\":\"images\\/FireShot Capture 2 - Admin - http___laravel-admin.local_demo_helpers_routes.png\"}');
INSERT INTO `demo_posts` VALUES(6, 'Dolores dolor aspernatur aut necessitatibus consequatur.', '114', 'Autem alias sequi assumenda qui quae vel molestias eos. Voluptatibus libero rem autem sunt non odit. Perspiciatis ratione quis placeat ea facilis.', 6, '1', 'consequatur', NULL, '1991-05-14 06:34:54', '2012-02-20 02:57:41', '2017-09-10 18:25:54', NULL, NULL);
INSERT INTO `demo_posts` VALUES(7, 'test111,zenmban,haolema,zenmbanne', '35', '{\"field1\":\"123123\",\"field2\":\"zosong@126.com\"}', 2, '1', '科技,生活,学习,健康', NULL, '0000-00-00 00:00:00', '2016-11-12 06:56:31', '2017-07-11 18:13:40', NULL, NULL);
INSERT INTO `demo_posts` VALUES(8, '123123 ', '114', 'asdasdasd', 0, '1', 'nihao,zenmban', NULL, '0000-00-00 00:00:00', '2016-12-12 06:36:53', '2017-01-22 07:15:11', NULL, NULL);
INSERT INTO `demo_posts` VALUES(9, '哈哈哈哈哈', '114', '啊实打实大s\'da\'s', 6, '1', '生活', NULL, '0000-00-00 00:00:00', '2016-12-16 17:18:54', '2017-07-11 18:21:13', NULL, NULL);
INSERT INTO `demo_posts` VALUES(10, 'hahahaha', '100', '你说什么呢', 2, '1', '', NULL, '0000-00-00 00:00:00', '2017-01-21 02:58:10', '2017-02-22 06:37:44', NULL, NULL);
INSERT INTO `demo_posts` VALUES(11, 'Asdasdasd', '114', 'asdasdasd', 2, '1', '', NULL, '0000-00-00 00:00:00', '2017-03-13 06:54:01', '2017-03-13 06:54:01', NULL, NULL);
INSERT INTO `demo_posts` VALUES(12, 'Distinctio porro debitis numquam neque veniam sequi ea.', 'sunt', 'Maxime et sed qui officia quas. Recusandae molestiae ut eveniet aliquid eos distinctio tempora sint. Tempore distinctio magni numquam corporis enim corrupti. Facilis quibusdam voluptas consequatur sed in laborum in.', 6, '1', 'qui', NULL, '2001-07-16 00:37:19', '2008-06-09 07:40:14', '2017-07-11 18:25:05', NULL, NULL);
INSERT INTO `demo_posts` VALUES(13, 'Laudantium quaerat dolores omnis cum culpa.', 'maiores', 'Repellat ducimus voluptas magni soluta numquam quia. Voluptatem sed ipsum molestiae. Repudiandae nulla quod ut sapiente qui fugiat minus. Voluptate non quo voluptatem recusandae consectetur.', 5, '0', 'aspernatur', NULL, '2001-11-01 18:58:55', '1983-09-09 22:03:24', '2017-07-11 18:21:13', NULL, NULL);
INSERT INTO `demo_posts` VALUES(14, 'Non aliquam totam numquam quo possimus quidem qui.', 'non', 'Est voluptatem quis eum voluptate nihil vero ut. Voluptas ipsum fugit accusamus commodi.', 9, '1', 'qui', NULL, '2002-05-19 19:02:16', '1996-10-10 09:00:56', '2017-07-12 19:47:03', NULL, NULL);
INSERT INTO `demo_posts` VALUES(15, 'Et veritatis est enim enim.', 'et', 'Et a quas dolore consectetur dolor quasi debitis. Dolor aspernatur eveniet veritatis. Commodi quibusdam voluptas dolore minus facilis aut.', 1, '0', 'impedit', NULL, '1983-01-04 12:38:33', '2016-06-16 11:08:50', '2017-07-11 18:21:13', NULL, NULL);
INSERT INTO `demo_posts` VALUES(16, 'aaaaaaa', '114', 'asdasdasdasdas', 2, '1', '', NULL, '0000-00-00 00:00:00', '2017-09-05 07:02:50', '2017-09-05 07:02:50', NULL, NULL);
INSERT INTO `demo_posts` VALUES(20, 'http://laravel-admin.local/demo/posts/create', '', '', 2, '1', '', NULL, '0000-00-00 00:00:00', '2017-09-20 14:50:15', '2017-09-20 14:50:15', NULL, NULL);
