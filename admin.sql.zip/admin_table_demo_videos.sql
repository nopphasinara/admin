
CREATE TABLE `demo_videos` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `video` text COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `release_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_videos` VALUES(3, 'asdasdas das d', 'files/loudness_convert.php', '2', '2016-12-20 16:00:00', '2016-11-13 06:04:22', '2017-09-12 23:01:04');
INSERT INTO `demo_videos` VALUES(4, 'hahahaahhhah', 'file/5630259_150032830000_2.jpg', '0,2,3', '2016-12-23 16:00:00', '2016-12-23 18:47:17', '2016-12-24 09:18:53');
INSERT INTO `demo_videos` VALUES(5, 'hahahh ', 'file/df0f3829a8d8492fda696e6847757c14.jpeg', '0,1,2,3', '2016-12-23 16:00:00', '2016-12-23 22:14:17', '2016-12-24 09:29:08');
INSERT INTO `demo_videos` VALUES(6, '你说啥呢', 'file/u=798459138,2950856503&fm=23&gp=0.jpg', '0,1,2,3', '2016-12-24 16:00:00', '2016-12-24 08:00:45', '2016-12-24 09:28:36');
