
CREATE TABLE `demo_tags` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `hot` tinyint(1) NOT NULL DEFAULT '0',
  `new` tinyint(1) NOT NULL DEFAULT '0',
  `recommend` tinyint(1) NOT NULL DEFAULT '0',
  `options` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_tags` VALUES(16, 'php', 0, 1, 1, '2,3,4', '2016-11-13 06:03:03', '2018-04-12 11:04:00');
INSERT INTO `demo_tags` VALUES(17, 'js', 1, 1, 1, '1', '2016-11-13 06:03:09', '2017-02-28 08:35:02');
INSERT INTO `demo_tags` VALUES(18, 'python', 1, 1, 1, '', '2016-11-13 06:03:16', '2017-02-28 08:35:04');
INSERT INTO `demo_tags` VALUES(20, 'ruby', 1, 1, 1, '', '2016-11-13 06:03:25', '2017-02-28 08:35:05');
INSERT INTO `demo_tags` VALUES(21, 'c++', 1, 0, 0, '', '2016-11-13 06:03:31', '2016-12-24 20:29:44');
INSERT INTO `demo_tags` VALUES(22, 'c#', 0, 1, 1, '', '2016-11-13 06:03:35', '2016-12-24 20:29:48');
INSERT INTO `demo_tags` VALUES(23, 'golang', 1, 0, 1, '', '2017-09-05 06:53:27', '2017-09-05 06:53:27');
