
CREATE TABLE `admin_permissions` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_permissions` VALUES(1, 'All permission', '*', '', '*', NULL, NULL);
INSERT INTO `admin_permissions` VALUES(2, 'Login', 'auth.login', '', '/auth/login\r\n/auth/logout', NULL, NULL);
INSERT INTO `admin_permissions` VALUES(3, 'User setting', 'auth.setting', 'GET,PUT', '/auth/setting', NULL, NULL);
INSERT INTO `admin_permissions` VALUES(4, 'Auth management', 'auth.management', '', '/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs', NULL, NULL);
INSERT INTO `admin_permissions` VALUES(5, 'Admin Config', 'ext.config', NULL, '/config*', '2017-07-20 19:45:42', '2017-07-20 19:45:42');
INSERT INTO `admin_permissions` VALUES(7, 'Admin messages', 'ext.messages', NULL, '/messages*', '2017-07-20 20:02:45', '2017-07-20 20:02:45');
INSERT INTO `admin_permissions` VALUES(8, 'Scheduling', 'ext.scheduling', NULL, '/scheduling*', '2017-08-29 08:25:28', '2017-08-29 08:25:28');
INSERT INTO `admin_permissions` VALUES(9, 'Logs', 'ext.log-viewer', NULL, '/logs*', '2017-08-29 08:35:32', '2017-08-29 08:35:32');
INSERT INTO `admin_permissions` VALUES(10, 'Api tester', 'ext.api-tester', NULL, '/api-tester*', '2017-08-31 04:46:46', '2017-08-31 04:46:46');
INSERT INTO `admin_permissions` VALUES(11, 'Dashboard', 'dashboard', 'GET', '/', '2017-09-02 20:25:07', '2017-09-02 20:25:07');
INSERT INTO `admin_permissions` VALUES(12, 'Backup', 'ext.backup', NULL, '/backup*', '2017-09-11 17:57:32', '2017-09-11 17:57:32');
INSERT INTO `admin_permissions` VALUES(13, '访问用户管理', 'demo.users', 'GET', '/users', '2017-09-13 17:34:36', '2017-09-13 17:34:36');
INSERT INTO `admin_permissions` VALUES(14, '编辑用户页面', 'demo.users.edit', 'GET', '/users/*/edit', '2017-09-13 17:35:54', '2017-09-13 17:35:54');
INSERT INTO `admin_permissions` VALUES(15, 'Media manager', 'ext.media-manager', NULL, '/media*', '2017-09-15 08:07:21', '2017-09-15 08:07:21');
INSERT INTO `admin_permissions` VALUES(16, 'Admin helpers', 'ext.helpers', NULL, '/helpers/*', '2017-09-27 06:31:15', '2017-09-27 06:31:15');
INSERT INTO `admin_permissions` VALUES(17, 'Exceptions reporter', 'ext.reporter', NULL, '/exceptions*', '2017-09-28 02:29:00', '2017-09-28 02:29:00');
