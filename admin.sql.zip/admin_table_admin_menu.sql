
CREATE TABLE `admin_menu` (
  `id` int(10) UNSIGNED NOT NULL,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_menu` VALUES(1, 0, 1, 'Dashboard', 'fa-bar-chart', '/', NULL, '2017-09-02 14:35:25');
INSERT INTO `admin_menu` VALUES(2, 0, 2, 'Admin', 'fa-tasks', '', NULL, NULL);
INSERT INTO `admin_menu` VALUES(3, 2, 3, 'Users', 'fa-users', 'auth/users', NULL, NULL);
INSERT INTO `admin_menu` VALUES(4, 2, 4, 'Roles', 'fa-user', 'auth/roles', NULL, NULL);
INSERT INTO `admin_menu` VALUES(5, 2, 5, 'Permission', 'fa-ban', 'auth/permissions', NULL, NULL);
INSERT INTO `admin_menu` VALUES(6, 2, 6, 'Menu', 'fa-bars', 'auth/menu', NULL, NULL);
INSERT INTO `admin_menu` VALUES(7, 2, 7, 'Operation log', 'fa-history', 'auth/logs', NULL, NULL);
INSERT INTO `admin_menu` VALUES(8, 0, 36, 'Config', 'fa-toggle-on', 'config', '2017-09-02 14:19:52', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(9, 0, 37, 'Scheduling', 'fa-clock-o', 'scheduling', '2017-09-02 14:19:54', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(10, 0, 38, 'Log viwer', 'fa-database', 'logs', '2017-09-02 14:19:57', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(11, 0, 39, 'Api tester', 'fa-sliders', 'api-tester', '2017-09-02 14:19:59', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(12, 0, 40, 'Media manager', 'fa-file', 'media', '2017-09-02 14:20:35', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(13, 0, 8, 'Demos', 'fa-align-center', '/', '2017-09-02 14:25:21', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(14, 13, 9, 'Users', 'fa-user-md', 'users', '2017-09-02 14:25:48', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(15, 13, 10, 'Posts', 'fa-book', 'posts', '2017-09-02 14:26:11', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(16, 13, 11, 'Images', 'fa-picture-o', 'images', '2017-09-02 14:26:30', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(17, 13, 12, 'Videos', 'fa-file-video-o', 'videos', '2017-09-02 14:26:57', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(18, 13, 13, 'Articles', 'fa-file-pdf-o', 'articles', '2017-09-02 14:27:35', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(19, 13, 14, 'Categories', 'fa-bars', 'categories', '2017-09-02 14:28:12', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(20, 13, 15, 'Multiple image', 'fa-file-image-o', 'multiple-images', '2017-09-02 14:28:32', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(21, 13, 17, 'Painters', 'fa-simplybuilt', 'painters', '2017-09-02 14:29:15', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(22, 13, 16, 'Tags', 'fa-tags', 'tags', '2017-09-02 14:29:30', '2017-09-02 14:29:45');
INSERT INTO `admin_menu` VALUES(23, 0, 22, 'China area', 'fa-map', '/', '2017-09-02 14:30:41', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(24, 23, 23, 'Provinces', 'fa-map-marker', 'china/province', '2017-09-02 14:31:35', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(25, 23, 24, 'Cities', 'fa-map-pin', 'china/city', '2017-09-02 14:31:59', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(26, 23, 25, 'District', 'fa-map-signs', 'china/district', '2017-09-02 14:32:16', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(27, 23, 26, 'Nested', 'fa-connectdevelop', 'china/nested', '2017-09-02 14:32:54', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(28, 0, 27, 'Data from api', 'fa-video-camera', '/', '2017-09-02 14:33:28', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(29, 28, 28, 'In theaters', 'fa-bars', 'movies/in-theaters', '2017-09-02 14:34:16', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(30, 28, 29, 'Coming soon', 'fa-bars', 'movies/coming-soon', '2017-09-02 14:34:36', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(31, 28, 30, 'top 250', 'fa-bars', 'movies/top250', '2017-09-02 14:34:53', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(32, 0, 44, '外部链接', 'fa-bars', 'http://laravel-admin.org/', '2017-09-07 18:21:24', '2017-09-30 03:25:05');
INSERT INTO `admin_menu` VALUES(33, 0, 41, 'Backup', 'fa-copy', 'backup', '2017-09-11 17:57:32', '2017-09-30 03:25:05');
INSERT INTO `admin_menu` VALUES(35, 0, 31, 'Helpers', 'fa-gears', '', '2017-09-27 06:31:15', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(36, 35, 32, 'Scaffold', 'fa-keyboard-o', 'helpers/scaffold', '2017-09-27 06:31:15', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(37, 35, 33, 'Database terminal', 'fa-database', 'helpers/terminal/database', '2017-09-27 06:31:15', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(38, 35, 34, 'Laravel artisan', 'fa-terminal', 'helpers/terminal/artisan', '2017-09-27 06:31:15', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(39, 35, 35, 'Routes', 'fa-list-alt', 'helpers/routes', '2017-09-27 06:31:15', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(40, 0, 43, 'Exception Reporter', 'fa-bug', 'exceptions', '2017-09-28 02:29:00', '2017-09-30 03:25:05');
INSERT INTO `admin_menu` VALUES(41, 0, 18, 'World', 'fa-map-o', NULL, '2017-09-30 03:03:43', '2017-09-30 03:04:32');
INSERT INTO `admin_menu` VALUES(42, 41, 19, 'Country', 'fa-bars', 'world/country', '2017-09-30 03:04:08', '2017-09-30 03:04:32');
INSERT INTO `admin_menu` VALUES(43, 41, 20, 'City', 'fa-map-marker', 'world/city', '2017-09-30 03:06:23', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(44, 41, 21, 'Language', 'fa-language', 'world/language', '2017-09-30 03:06:45', '2017-09-30 03:25:04');
INSERT INTO `admin_menu` VALUES(49, 0, 31, 'Widgets', 'fa-cubes', NULL, '2017-09-30 04:06:52', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(50, 49, 32, 'Form-1', 'fa-cube', 'widgets/form-1', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(51, 49, 33, 'Form-2', 'fa-cube', 'widgets/form-2', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(52, 49, 34, 'Form-3', 'fa-cube', 'widgets/form-3', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(53, 49, 35, 'Table', 'fa-cube', 'widgets/table', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(54, 49, 36, 'Box', 'fa-cube', 'widgets/box', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(55, 49, 37, 'Info box', 'fa-cube', 'widgets/info-box', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(56, 49, 38, 'Tab', 'fa-cube', 'widgets/tab', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(57, 49, 39, 'Notice', 'fa-cube', 'widgets/notice', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
INSERT INTO `admin_menu` VALUES(58, 49, 0, 'Editors', 'fa-edit', 'widgets/editors', '2017-09-30 04:07:31', '2017-09-30 06:44:22');
