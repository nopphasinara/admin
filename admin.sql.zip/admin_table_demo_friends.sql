
CREATE TABLE `demo_friends` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `friend_id` int(11) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `demo_friends` VALUES(1, 3, 6, 'foo');
INSERT INTO `demo_friends` VALUES(2, 3, 9, 'bar');
INSERT INTO `demo_friends` VALUES(3, 3, 12, 'baz');
