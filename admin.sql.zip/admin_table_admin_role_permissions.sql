
CREATE TABLE `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_role_permissions` VALUES(1, 1, NULL, NULL);
INSERT INTO `admin_role_permissions` VALUES(2, 8, NULL, NULL);
INSERT INTO `admin_role_permissions` VALUES(2, 9, NULL, NULL);
INSERT INTO `admin_role_permissions` VALUES(2, 11, NULL, NULL);
INSERT INTO `admin_role_permissions` VALUES(3, 2, NULL, NULL);
INSERT INTO `admin_role_permissions` VALUES(2, 13, NULL, NULL);
INSERT INTO `admin_role_permissions` VALUES(2, 14, NULL, NULL);
