
CREATE TABLE `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `admin_role_users` VALUES(1, 1, NULL, NULL);
INSERT INTO `admin_role_users` VALUES(2, 2, NULL, NULL);
INSERT INTO `admin_role_users` VALUES(2, 1, NULL, NULL);
INSERT INTO `admin_role_users` VALUES(3, 1, NULL, NULL);
