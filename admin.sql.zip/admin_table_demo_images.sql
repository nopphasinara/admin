
CREATE TABLE `demo_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `uploader` int(11) UNSIGNED NOT NULL,
  `caption` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_images` VALUES(2, 3, '222222', 'images/onlinelogomaker-090317-1909-6794.png', '2017-01-03 07:26:48', '2017-09-03 18:33:42');
INSERT INTO `demo_images` VALUES(3, 6, '12asdasd asd aasdasd', 'images/onlinelogomaker-090417-1656-8623.png', '2017-09-10 18:26:42', '2017-09-10 18:26:42');
INSERT INTO `demo_images` VALUES(4, 3, '123123', 'http://laravel-admin.local/uploads/images/0ef82c7958be686a3ea874fffa6a066b.png', '2017-09-25 03:36:29', '2017-09-25 03:55:57');
INSERT INTO `demo_images` VALUES(5, 3, '测试一下', 'images/04840a15d341ecd9e5903b6dde45fa2f.jpeg', '2017-09-25 04:01:06', '2017-09-25 04:01:13');
INSERT INTO `demo_images` VALUES(6, 3, '1111', 'http://laravel-admin.local/uploads/images/0ef82c7958be686a3ea874fffa6a066b.png', '2017-09-25 04:02:55', '2017-09-25 04:02:55');
