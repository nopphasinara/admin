
CREATE TABLE `demo_multiple_images` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pictures` text COLLATE utf8_unicode_ci,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_multiple_images` VALUES(1, '12313222223333', '[\"images\\/enid.png\",\"images\\/logo.png\",\"images\\/thumblogo.png\"]', '2017-02-20 06:54:34', '2017-09-19 02:21:57');
INSERT INTO `demo_multiple_images` VALUES(2, '12313222223333', '[]', '2017-09-26 02:53:21', '2017-09-26 03:02:53');
