
CREATE TABLE `demo_user_address` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `province_id` int(11) UNSIGNED DEFAULT '0',
  `city_id` int(11) UNSIGNED DEFAULT '0',
  `district_id` int(11) UNSIGNED DEFAULT '0',
  `address` varchar(255) COLLATE utf8_unicode_ci DEFAULT '',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `demo_user_address` VALUES(1, 6, 2, 52, 500, 'ahhahhaahhah', '2017-01-11 07:56:11', '2017-01-22 07:24:03');
INSERT INTO `demo_user_address` VALUES(2, 12, 2, 52, 500, '', '2017-01-22 07:24:30', '2017-01-22 07:25:02');
INSERT INTO `demo_user_address` VALUES(3, 18, 2, 52, 500, '', '2017-01-22 07:24:42', '2017-01-22 07:24:42');
INSERT INTO `demo_user_address` VALUES(4, 24, 2, 52, 500, '', '2017-01-22 07:25:20', '2017-01-22 07:25:20');
INSERT INTO `demo_user_address` VALUES(5, 3, 2, 0, 0, '', '2017-03-08 06:07:18', '2017-03-08 06:07:18');
INSERT INTO `demo_user_address` VALUES(6, 15, 2, 0, 0, '', '2017-03-08 06:07:29', '2017-03-08 06:07:29');
INSERT INTO `demo_user_address` VALUES(7, 9, 2, 0, 0, '', '2017-03-08 06:07:45', '2017-03-08 06:07:45');
